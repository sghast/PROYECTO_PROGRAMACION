#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pbnAgregar_clicked();
    void on_pbnCancelar_clicked();
    void on_pbnBuscar_clicked();
    void on_pbnEditar_clicked();
    void on_pbnEliminar_clicked();
    void on_pbnMostrarTodos_clicked();
    void on_pbnGuardar_clicked();

private:
    Ui::MainWindow *ui;
    QString idEnEdicion;
    bool idExiste(const QString &id);
    void cargarTabla();
    void limpiarCampos();
};

#endif
