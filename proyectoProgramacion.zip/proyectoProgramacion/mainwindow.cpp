#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFile>
#include <QTextStream>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    ui->twtInventario->setColumnCount(5);
    ui->twtInventario->setHorizontalHeaderLabels(
        {"ID", "Nombre", "Marca", "Precio", "Stock"}
        );
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::limpiarCampos()
{
    ui->txtID->clear();
    ui->txtNombre->clear();
    ui->txtMarca->clear();
    ui->spnPrecio->setValue(0.0);
    ui->sbxStock->setValue(0);
    ui->txtID->setFocus();
}

bool MainWindow::idExiste(const QString &id)
{
    QFile archivo("repuestos.txt");
    if (!archivo.open(QIODevice::ReadOnly | QIODevice::Text))
        return false;

    QTextStream in(&archivo);

    while (!in.atEnd()) {
        QString linea = in.readLine();
        QStringList datos = linea.split(";");
        if (datos[0] == id) {
            archivo.close();
            return true;
        }
    }
    archivo.close();
    return false;
}

void MainWindow::on_pbnAgregar_clicked()
{
    if (!idEnEdicion.isEmpty()) {
        QMessageBox::warning(this, "Aviso", "No puede agregar mientras está editando un repuesto");
        return;
    }

    QString idTexto = ui->txtID->text().trimmed();

    if (idTexto.isEmpty()) {
        QMessageBox::warning(this, "Error", "Ingrese un ID");
        return;
    }

    bool ok;
    int id = idTexto.toInt(&ok);

    if (!ok || id < 0 || id > 9999) {
        QMessageBox::warning(this, "Error", "El ID debe estar entre 0 y 9999");
        return;
    }

    if (idExiste(idTexto)) {
        QMessageBox::warning(this, "Error", "El ID ya existe");
        return;
    }

    QFile archivo("repuestos.txt");
    if (!archivo.open(QIODevice::Append | QIODevice::Text)) {
        QMessageBox::critical(this, "Error", "No se pudo abrir el archivo");
        return;
    }

    QTextStream out(&archivo);
    out << idTexto << ";"
        << ui->txtNombre->text().trimmed() << ";"
        << ui->txtMarca->text().trimmed() << ";"
        << ui->spnPrecio->value() << ";"
        << ui->sbxStock->value() << "\n";

    archivo.close();

    limpiarCampos();
    cargarTabla();
}

void MainWindow::on_pbnBuscar_clicked()
{
    QString idBuscado = ui->txtBuscar->text().trimmed();

    if (idBuscado.isEmpty()) {
        QMessageBox::warning(this, "Aviso", "Ingrese un ID para buscar");
        return;
    }

    ui->twtInventario->setRowCount(0);

    QFile archivo("repuestos.txt");
    if (!archivo.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::critical(this, "Error", "No se pudo abrir repuestos.txt");
        return;
    }

    QTextStream in(&archivo);
    bool encontrado = false;

    while (!in.atEnd()) {
        QString linea = in.readLine();
        QStringList datos = linea.split(";");

        if (datos.size() != 5) continue;

        if (datos[0].trimmed() == idBuscado) {
            int fila = ui->twtInventario->rowCount();
            ui->twtInventario->insertRow(fila);

            for (int col = 0; col < 5; col++) {
                ui->twtInventario->setItem(
                    fila, col,
                    new QTableWidgetItem(datos[col].trimmed())
                    );
            }

            encontrado = true;
            break;
        }
    }

    archivo.close();

    if (!encontrado) {
        QMessageBox::information(this, "Resultado", "Repuesto no encontrado");
    }
}

void MainWindow::on_pbnEditar_clicked()
{
    QString idBuscar = ui->txtBuscar->text().trimmed();

    if (idBuscar.isEmpty()) {
        QMessageBox::warning(this, "Aviso", "Ingrese un ID para editar");
        return;
    }

    QFile archivo("repuestos.txt");
    if (!archivo.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::critical(this, "Error", "No se pudo abrir repuestos.txt");
        return;
    }

    QTextStream in(&archivo);
    bool encontrado = false;

    while (!in.atEnd()) {
        QStringList d = in.readLine().split(";");

        if (d.size() != 5) continue;

        if (d[0].trimmed() == idBuscar) {

            ui->txtID->setText(d[0].trimmed());
            ui->txtNombre->setText(d[1].trimmed());
            ui->txtMarca->setText(d[2].trimmed());
            ui->spnPrecio->setValue(d[3].toDouble());
            ui->sbxStock->setValue(d[4].toInt());

            idEnEdicion = d[0].trimmed();

            ui->pbnAgregar->setEnabled(false);

            encontrado = true;
            break;
        }
    }

    archivo.close();

    if (!encontrado) {
        QMessageBox::information(this, "Aviso", "Repuesto no encontrado");
    }
}

void MainWindow::on_pbnEliminar_clicked()
{
    QString idEliminar = ui->txtBuscar->text().trimmed();

    QFile archivo("repuestos.txt");
    QFile temp("temp.txt");

    if (!archivo.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::critical(this, "Error", "No se pudo abrir repuestos.txt");
        return;
    }

    if (!temp.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::critical(this, "Error", "No se pudo crear archivo temporal");
        archivo.close();
        return;
    }

    QTextStream in(&archivo);
    QTextStream out(&temp);

    bool eliminado = false;

    while (!in.atEnd()) {
        QStringList d = in.readLine().split(";");
        if (d[0] != idEliminar)
            out << d.join(";") << "\n";
        else
            eliminado = true;
    }

    archivo.close();
    temp.close();

    QFile::remove("repuestos.txt");
    QFile::rename("temp.txt", "repuestos.txt");

    if (eliminado)
        cargarTabla();
}

void MainWindow::cargarTabla()
{
    ui->twtInventario->setRowCount(0);

    QFile archivo("repuestos.txt");

    if (!archivo.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::critical(this, "Error", "No se pudo abrir repuestos.txt");
        return;
    }

    QTextStream in(&archivo);
    int fila = 0;

    while (!in.atEnd()) {
        QStringList d = in.readLine().split(";");
        ui->twtInventario->insertRow(fila);
        for (int c = 0; c < 5; c++)
            ui->twtInventario->setItem(fila, c, new QTableWidgetItem(d[c]));
        fila++;
    }
    archivo.close();
}

void MainWindow::on_pbnMostrarTodos_clicked()
{
    cargarTabla();
}

void MainWindow::on_pbnGuardar_clicked()
{
    if (idEnEdicion.isEmpty()) {
        QMessageBox::warning(this, "Aviso", "No hay ningún repuesto en edición");
        return;
    }

    QFile archivo("repuestos.txt");
    QFile temp("temp.txt");

    if (!archivo.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::critical(this, "Error", "No se pudo abrir repuestos.txt");
        return;
    }

    if (!temp.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::critical(this, "Error", "No se pudo crear archivo temporal");
        archivo.close();
        return;
    }

    QTextStream in(&archivo);
    QTextStream out(&temp);

    while (!in.atEnd()) {
        QString linea = in.readLine();
        QStringList d = linea.split(";");

        if (d.size() != 5) continue;

        if (d[0].trimmed() == idEnEdicion) {
            out << ui->txtID->text().trimmed() << ";"
                << ui->txtNombre->text().trimmed() << ";"
                << ui->txtMarca->text().trimmed() << ";"
                << ui->spnPrecio->value() << ";"
                << ui->sbxStock->value() << "\n";
        } else {
            out << linea << "\n";
        }
    }

    archivo.close();
    temp.close();

    QFile::remove("repuestos.txt");
    QFile::rename("temp.txt", "repuestos.txt");

    idEnEdicion.clear();
    ui->pbnAgregar->setEnabled(true);

    limpiarCampos();
    cargarTabla();
}

void MainWindow::on_pbnCancelar_clicked()
{
    limpiarCampos();
    idEnEdicion.clear();
    ui->pbnAgregar->setEnabled(true);
}
